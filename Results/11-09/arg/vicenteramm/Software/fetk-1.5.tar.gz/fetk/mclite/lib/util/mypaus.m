%MYPAUS  Pause and print a message requesting a carriage return to continue
%
% Usage: mypaus;
%
% Author:   Michael Holst
% rcsid="$Id: mypaus.m,v 1.1.1.1 2007/04/27 08:28:19 hrg Exp $"

fprintf(' --- press return ---\n'); 
pause;

