%MCLITEHI Print the MCLite GNU License Message
%
% Usage:  mclitehi
%
% Author:   Michael Holst
% rcsid="$Id: mclitehi.m,v 1.1.1.1 2007/04/27 08:28:19 hrg Exp $"

fprintf('------------------------------------------------------------------------------\n');
fprintf('MCLite version 1.0, Copyright (C) 1998 Michael Holst\n');
fprintf('\n');
fprintf('This is free software, and you are welcome to redistribute it\n');
fprintf('under certain conditions; see the file "COPYING" for details.\n');
fprintf('Note that MCLite comes with ABSOLUTELY NO WARRANTY.\n');
fprintf('\n');
fprintf('For MCLite documentation:  In MATLAB, type "help".\n');
fprintf('------------------------------------------------------------------------------\n');

