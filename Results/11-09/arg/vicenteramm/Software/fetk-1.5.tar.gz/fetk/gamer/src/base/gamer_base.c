
#include "gamercf.h"

/*
 * ***************************************************************************
 * Routine:  gamer_link, gamer_needs_XXX
 *
 * Purpose:  Autoconf linkage assistance for packages built on top of GAMER.
 *
 * Author:   Michael Holst
 * ***************************************************************************
 */
void gamer_link(void)
{
}

