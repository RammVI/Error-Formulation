""" Python interface of MC
"""

__author__ = "Johan Hake (hake.dev@gmail.com)"
__copyright__ = "Copyright (C) 2010 Johan Hake"
__date__ = "2010-10-01 -- 2010-10-01"
__license__  = "GNU LGPL Version 3.0"

# Import the wrapped SWIG wrapped version of MC
import cmc

