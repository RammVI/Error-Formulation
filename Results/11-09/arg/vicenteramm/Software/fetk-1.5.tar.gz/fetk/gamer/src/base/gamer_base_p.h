
/*
 * ***************************************************************************
 * File:     gamer_base_p.h
 *
 * Purpose:  PRIVATE header.
 *
 * Author:   Michael Holst
 * ***************************************************************************
 */

#ifndef _GAMER_BASE_P_H_
#define _GAMER_BASE_P_H_

#include <gamer/gamer_base.h>
#include "gamercf.h"

#endif /* _GAMER_BASE_P_H_ */

